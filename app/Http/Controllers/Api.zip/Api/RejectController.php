<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OrderAccept;
use App\Models\Agent;
use Illuminate\Support\Facades\Validator;

class RejectController extends Controller
{
    public function OrderReject(Request $request)
    {
        $authorization = $request->header('Authorization');
        $tokenWithoutBearer = str_replace("Bearer ", "", $authorization);
        $accessToken = Agent::where('token', $tokenWithoutBearer)->first();

        if ($accessToken) {
            $records = $request->json()->all();

                $reject = new OrderAccept();
                $reject->agent_id = $accessToken->id;
                $reject->party_id = $request->party_id;
                $reject->item_id = $request->item_id;
                $reject->reason = $request->reason;
                $reject->status = 0;

                $reject->save();

            $data['success'] = true;
            $data['data'] = $reject;
            $data['message'] = "Not Accept Orders";
        } else {
            $data['success'] = false;
            $data['message'] = "Invalid access token";
        }

        return response()->json($data);
    }

}
