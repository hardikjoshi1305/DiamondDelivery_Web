<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\OrderAccept;
use App\Models\Agent;
use App\Models\DiamondList;
use Illuminate\Support\Facades\Validator;



class AcceptController extends Controller
{
    public function OrderAccept(Request $request)
    {
        $authorization = $request->header('Authorization');
        $tokenWithoutBearer = str_replace("Bearer ", "", $authorization);
        $accessToken = Agent::where('token', $tokenWithoutBearer)->first();


         $item=DiamondList::find($request->item_id);
          $remainin= $item->remaining_weight-$request->weight;
         $item->remaining_weight= $remainin;
         if ($remainin <= 0) {
            $item->status = 1;
        } else {
            $item->status = 0;
        }
         $item->save();

        if ($accessToken) {
            $records = $request->json()->all();

                $accept = new OrderAccept();
                $accept->agent_id = $accessToken->id;
                $accept->party_id = $request->party_id;
                $accept->item_id = $request->item_id;
                $accept->amount = $request->amount;
                $accept->weight = $request->weight;
                $accept->status = 1;

                $accept->save();


            $data['success'] = true;
            $data['data'] = $accept;
            $data['message'] = "Successfully Accept Orders";
        } else {
            $data['success'] = false;
            $data['message'] = "Invalid access token";
        }

        return response()->json($data);
    }


}
